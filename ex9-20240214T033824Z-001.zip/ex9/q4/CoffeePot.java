public class CoffeePot {
    
    public void doCoffeePot(Alarm alarm) {
        System.out.println("I am coffe pot,... doing my task");
        alarm.endAlarm("Coffee Pot");
    }

}
